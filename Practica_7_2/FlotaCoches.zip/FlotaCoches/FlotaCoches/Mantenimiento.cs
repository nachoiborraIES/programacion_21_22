﻿using System;
using System.Collections.Generic;

/*
 * Clase referente a los Mantenimientos de los coches.
 */

class Mantenimiento
{
    private string fecha;
    private string descripcion;
    private float precio;

    public string Fecha
    {
        get { return fecha; }
        set { fecha = value; }
    }

    public string Descripcion
    {
        get { return descripcion; }
        set { descripcion = value; }
    }

    public float Precio
    {
        get { return precio; }
        set { precio = value; }
    }

    public Mantenimiento(string fecha, string descripcion, float precio)
    {
        Fecha = fecha;
        Descripcion = descripcion;
        Precio = precio;
    }

    public override string ToString()
    {
        return "Fecha: "+Fecha+", Descripción: "+Descripcion+", Precio: "+
            Precio;
    }
}