﻿using System;
using System.Collections.Generic;

/*
 * Clase referente a los coches almacenados.
 */
class Coche
{
    private string matricula;
    private string marca;
    private string modelo;
    private List<Mantenimiento> mantenimientos;

    public string Matricula
    {
        get { return matricula; }
        set { matricula = value; }
    }

    public string Marca
    {
        get { return marca; }
        set { marca = value; }
    }

    public string Modelo
    {
        get { return modelo; }
        set { modelo = value; }
    }

    public Coche(string matricula,
        string marca, string modelo)
    {
        this.mantenimientos = new List<Mantenimiento>();
        Matricula = matricula;
        Marca = marca;
        Modelo = modelo;
    }

    public override string ToString()
    {
        return "Matricula: "+Matricula+"\n"+
            "Marca: "+ Marca+"\n"+
            "Modelo: "+Modelo;
    }

    public void AñadirMantenimientos(Mantenimiento nMantenimiento)
    {
        this.mantenimientos.Add(nMantenimiento);
    }

    public void MostrarMantenimientos()
    {
        for(int i=0; i<this.mantenimientos.Count; i++)
        {
            Console.WriteLine(mantenimientos[i].ToString());
        }
    }

    public float TotalMantenimientos()
    {
        float total = 0;

        for(int i=0; i<this.mantenimientos.Count; i++)
        {
            total += this.mantenimientos[i].Precio;      
        }

        return total;
    }
}