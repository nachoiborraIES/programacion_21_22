﻿using System;
using System.Collections;
using System.Collections.Generic;

/*
 * Clase donde se ejecuta el programa principal.
 * Hecho por Daniel Marín Giner.
 */

class Principal
{
    static void Main()
    {
        int op = 0;
        Dictionary<string, Coche> coches= new Dictionary<string, Coche>();

        coches.Add("1111ABC", new Coche("1111ABC", "Opel", "Corsa"));
        coches.Add("1222BBB", new Coche("1222BBB", "Mercedes", "Benz"));
        coches.Add("2333CCC", new Coche("2333CCC", "Ford", "Fiesta"));
        coches.Add("3444DDD", new Coche("3444DDD", "Renault", "Clio"));

        do
        {
            Console.WriteLine("1. Nuevo Mantenimiento.");
            Console.WriteLine("2. Coche más problemático.");
            Console.WriteLine("3. Listar coches.");
            Console.WriteLine("4. Reemplazar coche.");
            Console.WriteLine("5. Salir.");
            Console.WriteLine("Selecciona una opción.");
            op= Convert.ToInt32(Console.ReadLine());

            Console.Clear();

            switch (op)
            {
                case 1:
                    MostrarLista(coches);
                    NuevoMantenimiento(coches);
                    break;
                case 2:
                    CocheMasProblematico(coches);
                    break;
                case 3:
                    MostrarLista(coches);
                    break;
                case 4:
                    MostrarLista(coches);
                    ReemplazarCoche(coches);
                    break;
                case 5:
                    Console.WriteLine("Has salido");
                    break;
                default:
                    Console.WriteLine("Opcion incorrecta");
                    break;
            }
        } while (op != 5);

    }

    static void NuevoMantenimiento(Dictionary<string, Coche> coches)
    {
        string matricula, fecha, desc;
        float precio;
        Mantenimiento aux;
        Console.WriteLine("Selecciona un coche por su matricula: ");
        matricula = Console.ReadLine();

        if(BuscarCoche(coches, matricula))
        {
            Console.WriteLine("Fecha del mantenimiento: ");
            fecha= Console.ReadLine();

            Console.WriteLine("Descripcción: ");
            desc= Console.ReadLine();

            Console.WriteLine("Precio");
            precio= Convert.ToSingle(Console.ReadLine());

            aux= new Mantenimiento(fecha, desc, precio);

            coches[matricula].AñadirMantenimientos(aux);
        }
        else
        {
            Console.WriteLine("El coche no existe.");
        }
    }

    static void ReemplazarCoche(Dictionary<string, Coche> coches)
    {
        string matricula, marca, modelo;
        Console.WriteLine("Dime la matricula: ");
        matricula= Console.ReadLine();

        if(BuscarCoche(coches, matricula))
        {
            Console.WriteLine("Coche a reemplazar: ");
            Console.WriteLine(coches[matricula].ToString());

            coches.Remove(matricula);

            Console.WriteLine("Nueva matricula: ");
            matricula = Console.ReadLine();

            Console.WriteLine("Nueva marca: ");
            marca= Console.ReadLine();

            Console.WriteLine("Nuevo modelo: ");
            modelo= Console.ReadLine();

            coches.Add(matricula, new Coche(matricula, marca, modelo));
        }
        else
        {
            Console.WriteLine("El coche no existe");
        }

        
    }

    static void MostrarLista(Dictionary<string, Coche> coches)
    {
        IDictionaryEnumerator enumerador = coches.GetEnumerator();
        while (enumerador.MoveNext())
        {
            Console.WriteLine(enumerador.Value.ToString());
            Console.WriteLine(" ");
        }
    }

    static bool BuscarCoche(Dictionary<string, Coche> coches, 
        string matricula)
    {
        if (coches.ContainsKey(matricula))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    static void CocheMasProblematico(Dictionary<string, Coche> coches)
    {
        IDictionaryEnumerator enumerador = coches.GetEnumerator();
        Console.WriteLine("Coche mas problematico con sus mantenimientos: ");
        Coche mayor=new Coche("", "", "");
        float mayorprecio=0;
        while (enumerador.MoveNext())
        {
            if(((Coche)enumerador.Value).TotalMantenimientos() > mayorprecio)
            {
                mayor = (Coche)enumerador.Value;
                mayorprecio= mayor.TotalMantenimientos();
            }
        }

        Console.WriteLine(mayor.ToString());
        mayor.MostrarMantenimientos();
    }
}