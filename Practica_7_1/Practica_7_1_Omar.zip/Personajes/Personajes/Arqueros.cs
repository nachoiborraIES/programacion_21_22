﻿/*Los Arqueros, de los que guardaremos la longitud de su arco
*/

using System;

class Arqueros : Personaje 
{
    protected int longitud;

    public Arqueros(string nombre, int vida, int longitud)
        : base (nombre, vida)
    {
        this.longitud = longitud;
    }

    public int GetLongitud()
    {
        return longitud;
    }

    public void SetLongitud(int valor)
    {
        longitud = valor;
    }

    public override string ToString()
    {
        return "Arquero: " + base.ToString()
            + ", longitud de su arma es: " + longitud;
    }

}

