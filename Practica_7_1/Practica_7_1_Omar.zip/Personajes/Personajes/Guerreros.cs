﻿/*Los Guerreros, de los que guardaremos el material de su espada*/
using System;

class Guerreros : Personaje
{ 
    protected string material;

    public Guerreros(string nombre, int vida, string material)
        : base(nombre, vida)
    {
        this.material = material;
    }

    public string GetMaterial()
    {
        return material;
    }

    public void SetMaterial(string valor)
    {
        material = valor;
    }

    public override string ToString()
    {
        return "Guerrero: " + base.ToString()
            + ", el material del arco es: " + material;
    }

}

