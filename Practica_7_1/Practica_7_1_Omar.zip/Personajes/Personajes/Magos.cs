﻿/*Los Magos de los que guardaremos su poder mágico (entero de 1 a 10)*/
using System;

class Magos : Personaje 
{
    protected int poder;

    public Magos(string nombre, int vida, int poder)
        : base(nombre, vida)
    {
        if (poder <= 10 && poder >= 1)
        {
            this.poder = poder;
        }
    }

    public int GetPoder()
    {
        return poder;
    }

    public void SetPoder(int valor)
    {
        if(valor <= 10 && valor >=1)
        {
            poder = valor;
        }
        
    }

    public override string ToString()
    {
        return "Mago: " + base.ToString()
            + ", su poder es: " + poder;
    }

}

