﻿/*
 1. Clase Personaje y subtipos

Crearemos una clase padre abstracta llamada Personaje,
que almacenará los datos generales de cualquier personaje
del programa: su nombre y su nivel de vida (entero de 0 a 100).
En el constructor asignaremos el nombre y el nivel de vida.
Distinguiremos 3 tipos de personajes:

Los Arqueros, de los que guardaremos la longitud de su arco
Los Guerreros, de los que guardaremos el material de su espada
Los Magos de los que guardaremos su poder mágico (entero de 1 a 10)


Añadid en cada clase los get/set y métodos que creáis necesarios,
junto con el correspondiente método ToString para sacar la información
de cada personaje en una línea, indicando también el tipo de personaje
que es (arquero, guerrero o mago).

2. Programa principal

En el programa principal (fichero Program.cs) se creará una
lista genérica vacía de personajes y se pedirá al usuario que
elija una de las siguientes opciones del menú:

- Nuevo personaje:
Pediremos al usuario por teclado que elija un tipo
de personaje e introduzca sus datos, añadiendo el nuevo personaje al
final de la lista. Deberemos verificar que el nivel de vida sea correcto
(entre 0 y 100), repitiendo el dato hasta que lo sea. Al finalizar,
mostrará el listado actualizado de personajes.

- Personajes por nivel de vida:
Ordenará el listado de mayor a menor nivel
de vida, y mostrará los datos de los personajes.

- Quitar personaje:
Le pedirá al usuario que escriba el nombre de un personaje
y, si se encuentra en la lista, lo eliminará y mostrará la lista resultante.
Si no se encuentra mostrará 'No se encuentra el personaje'
y no mostrará nada más. Si hay varios personajes con el mismo nombre,
se borrarán todos ellos.

- Personajes con poca vida:
Mostrará los personajes del listado que
tengan menos de 10 puntos de vida. Si no hay ningún personaje con esas
características, mostraremos el mensaje 'Todos los personajes
tienen vida suficiente'.

- Personaje con más vida:
Mostrará los datos del personaje con más
vida de la lista. Si no hay personajes, mostrará 'La lista está vacía'.

Salir
*/

using System;
using System.Collections.Generic;

enum opciones { NUEVO = 1, ORDVIDA,
	QUITAR, POCAVIDA, MASVIDA, SALIR = 0 }


class Program
{
	static int Menu()
	{
		int opcion;

		Console.WriteLine("Elige una opción del menú");
		Console.WriteLine("Menú de opciones:");
		Console.WriteLine((int)opciones.NUEVO +
			". Nueva Personaje");
		Console.WriteLine((int)opciones.ORDVIDA +
			". Ordenar personajes por nivel de vida");
		Console.WriteLine((int)opciones.QUITAR +
			". Quitar Personaje");
		Console.WriteLine((int)opciones.POCAVIDA +
			". Personajes con poca vida");
		Console.WriteLine((int)opciones.MASVIDA +
			". Personaje con más vida");
		Console.WriteLine((int)opciones.SALIR +
			". Salir");
		Console.WriteLine();

		opcion = Convert.ToInt32(Console.ReadLine());

		return opcion;
	}

	
	
	static void NuevoPersonaje(List<Personaje> personajes)
	{

		Personaje NuevoPersonaje;

		string nombre, material;

		int vida, eleccion, longitud, poder;


		Console.WriteLine("Indica que quieres añadir: \n" +
				"1-Arqueros | 2-Guerreros | 3-Magos");

		eleccion = Convert.ToInt32(Console.ReadLine());


		Console.WriteLine("Indica nombre");
		nombre = Console.ReadLine();

		do
		{
			Console.WriteLine("Introduce la vida");
			vida = Convert.ToInt32(Console.ReadLine());
		}
		while (vida > 100 || vida < 0 );

		if (eleccion == 1)
		{
			Console.WriteLine("Introduce la longitud del arco");
			longitud = Convert.ToInt32(Console.ReadLine());

			Console.WriteLine("Arquero dada de alta");
			Console.WriteLine();


			NuevoPersonaje = new Arqueros(nombre, vida, longitud);

			personajes.Add(NuevoPersonaje);
		}
		else if (eleccion == 2)
        {
			Console.WriteLine("Indica el material de su espada");
			material = Console.ReadLine();

			Console.WriteLine("Guerrero dada de alta");
			Console.WriteLine();

			NuevoPersonaje = new Guerreros(nombre, vida, material);

			personajes.Add(NuevoPersonaje);

		}
        else
        {
			do
			{
				Console.WriteLine("Introduce el poder");
				poder = Convert.ToInt32(Console.ReadLine());
			}
			while (poder > 10 || poder < 1);

			Console.WriteLine("Mago dada de alta");
			Console.WriteLine();

			NuevoPersonaje = new Magos(nombre, vida, poder);

			personajes.Add(NuevoPersonaje);
		}

		MostrarListado(personajes);

	}

	static void MostrarListado(List<Personaje> personajes)
    {
		foreach (Personaje p in personajes)
		{
			Console.WriteLine(p);
		}
		Console.WriteLine();
	}

	static void OrdenarVida(List<Personaje> personajes)
    {
		personajes.Sort();

		MostrarListado(personajes);
		Console.WriteLine();
	}

	static void QuitarPersonaje(List<Personaje> personajes)
	{
		string nombreAbuscar;
		int i=0, contador=0;

		Console.WriteLine("Dime el nombre del personaje" +
			"que quieres quitar");
		nombreAbuscar = Console.ReadLine();

		while (i < personajes.Count)
		{

			if (personajes[i].GetNombre().ToUpper()
				== nombreAbuscar.ToUpper())
			{
				personajes.RemoveAt(i);
				contador++;
			}
			else
			{
				i++;
			}
		}

		if(contador==0)
        {
			Console.WriteLine("No se encuentra el personaje");
			Console.WriteLine();
		}
        else
        {
			MostrarListado(personajes);
		}
		
	}
	static void MostraPocaVida(List<Personaje> personajes)
    {
		int contador = 0;
		foreach (Personaje p in personajes)
		{
			if(p.GetVidas()<10)
            {
				contador++;
				Console.WriteLine(p);
            }
		}
		if (contador == 0)
		{
			Console.WriteLine("Todos los personajes" +
					" tienen vida suficiente");

		}
		Console.WriteLine();
	}

	static void MayorVida(List<Personaje> personajes)
    {
		

		if (personajes.Count > 0)
		{
			personajes.Sort();
			Console.WriteLine(personajes[0]);
		}
        else
        {
			Console.WriteLine("La lista está vacía");

		}
		Console.WriteLine();
	}


	static void Main()
    {
        List<Personaje> personajes = new List<Personaje>();
		int opcion;
		
		do
		{
			opcion = Menu();

			switch ((opciones)opcion)
			{
				case opciones.NUEVO:
					NuevoPersonaje(personajes);
					break;

				case opciones.ORDVIDA:
					OrdenarVida(personajes);
					break;
				
				case opciones.QUITAR:
					QuitarPersonaje(personajes);
					break;
				
				case opciones.POCAVIDA:
					MostraPocaVida(personajes);
					break;

				case opciones.MASVIDA:
					MayorVida(personajes);
					break;
				
				case opciones.SALIR:
					Console.WriteLine("Fin del programa");
					break;
				default:
					Console.WriteLine("Opción incorrecta");
					break;
			}
		}
		while (opcion != (int)opciones.SALIR);

	}
}

