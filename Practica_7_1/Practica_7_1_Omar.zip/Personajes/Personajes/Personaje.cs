﻿/*
 Crearemos una clase padre abstracta llamada Personaje,
que almacenará los datos generales de cualquier personaje
del programa: su nombre y su nivel de vida (entero de 0 a 100).
En el constructor asignaremos el nombre y el nivel de vida.
*/
using System;

abstract public class Personaje : IComparable<Personaje>
{
    protected string nombre;
    protected int vida;

    protected Personaje(string nombre, int vida)
    {
        this.nombre = nombre;
        if (vida < 100 || vida > 0)
        {
            this.vida = vida;
        }
    }

    public string GetNombre()
    {
        return nombre;
    }

    public void SetNombre(string valor)
    {
        nombre = valor;
    }

    public int GetVidas()
    {
        return vida;
    }

    public void SetVida(int valor)
    {
        if( valor < 100 || valor > 0)
        {
            vida = valor;
        }   
    }


   public int CompareTo(Personaje otro)
    {
        return otro.vida.CompareTo(this.vida);
    }

    public override string ToString()
    {
        return "El nombre es: " + nombre
            + " , tiene " + vida + " vidas";
    }

}

