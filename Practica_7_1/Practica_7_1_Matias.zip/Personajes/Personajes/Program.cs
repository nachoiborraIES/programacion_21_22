﻿/*
 * Matías Agustín Piombo
 * 
 * Programa parra gestionar diferentes tipos de personajes de una lista.
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        List<Personaje> pers = new List<Personaje>();

        Menu(pers);
    }

    static void Menu(List<Personaje> p)
    {
        const int vidaMin = 10;
        int ops = 0;
        bool salir=false;

        while (!salir)
        {
            Console.WriteLine("\nMenú.\n");
            Console.WriteLine("Introduce la opción \n1. Nuevo personaje " +
                "\n2. Ordenar personajes por vida " +
                "\n3. Borrar personaje por nombre " +
                "\n4. Mostrar personajes con menos de {0} de vida " +
                "\n5. Mostrar el personaje con más vida " +
                "\n6. Salir\n", vidaMin);
            ops = Convert.ToInt32(Console.ReadLine());
            switch (ops)
            {
                case 1:
                    Nuevo(p);
                    break;
                case 2:
                    Ordenar(p);
                    break;
                case 3:
                    Borrar(p);
                    break;
                case 4:
                    PocaVida(p, vidaMin);
                    break;
                case 5:
                    if (p.Count <= 0)
                        Console.WriteLine("La lista está vacía.");
                    else
                        Console.WriteLine(MasVida(p).ToString());
                    Console.WriteLine();
                    break;
                case 6:
                    salir = true;
                    break;
                default:
                    Console.WriteLine("Opcion incorrecta.");
                    break;
            }
        }
        Console.WriteLine("Fin del programa.");
    }

    static void Nuevo(List<Personaje> p)
    {
        string nombre, material;
        int vida, tipo, poder;
        float longitud;
        Console.WriteLine("Nuevo Personaje.");
        Console.Write("Introduce el número del tipo que quieras crear" +
            " (1. Mago, 2. Guerrero, 3. Arquero): ");
        tipo = Convert.ToInt32(Console.ReadLine());
        Console.Write("Introduce el nombre: ");
        nombre = Console.ReadLine();
        do
        {
            Console.Write("Introduce la vida (0 a 100): ");
            vida = Convert.ToInt32(Console.ReadLine());
        } while (vida < 0 || vida > 100);

        switch (tipo)
        {
            case 1:
                do { 
                    Console.Write("Introduce el nivel de poder (1 a 10): ");
                    poder = Convert.ToInt32(Console.ReadLine());
                } while (poder < 1 || poder > 10);
                p.Add(new Magos(nombre, vida, poder));
                break;
            case 2:
                Console.Write("Introduce el material de la espada: ");
                material = Console.ReadLine();
                p.Add(new Guerreros(nombre, vida, material));
                break;

            case 3:
                Console.Write("Introduce la longitud del arco: ");
                longitud = Convert.ToSingle(Console.ReadLine());
                p.Add(new Arqueros(nombre, vida, longitud));
                break;
            default:
                Console.WriteLine("Tipo incorrecto.");
                break;
        }
        Mostrar(p);
    }

    static void Ordenar(List<Personaje> p)
    {
        p.Sort();

        Mostrar(p);
    }
    static void Borrar(List<Personaje> p)
    {
        string nombre;
        int i = 0;
        bool existe=false;
        Console.Write("Introduce el nombre del personaje a borrar: ");
        nombre=Console.ReadLine();
        while( i < p.Count)
        {
            if (nombre == p[i].GetNombre())
            {
                existe = true;
                p.RemoveAt(i);
            }
            else
                i++;
        }
        if (!existe)
            Console.WriteLine("No existe el personaje " + nombre);
        else
            Mostrar(p);

    }
    static void PocaVida(List<Personaje> p, int vidaMin)
    {
        bool existe = false;
        for (int i = 0; i < p.Count; i++)
        {
            if (p[i].GetVida() < vidaMin)
            {
                existe = true;
                Console.WriteLine(p[i].ToString());
            }
        }
        if (!existe)
            Console.WriteLine("Todos los personajes tienen vida suficiente");
    }
    static Personaje MasVida(List<Personaje> p)
    {
        Personaje aux = p[0];
        for (int i = 0; i < p.Count; i++)
        {
            if (aux.GetVida() < p[i].GetVida())
                aux = p[i];
        }
        return aux;
    }

    static void Mostrar(List<Personaje> p)
    {
        Console.WriteLine("\nPersonajes:");
        foreach (Personaje forP in p)
        {
            Console.WriteLine(forP.ToString());
        }
    }
}