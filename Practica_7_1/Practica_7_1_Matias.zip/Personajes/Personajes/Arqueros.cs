﻿//Clase Arqueros hijo de Personaje
class Arqueros : Personaje
{
    private float longitud;
    public Arqueros(string nombre, int vida, float longitud) : 
        base(nombre, vida)
    {
        this.longitud = longitud;
    }

    public override string ToString()
    {
        return "Arquero: " + base.ToString() + ". Longitud: " + longitud;
    }

}
