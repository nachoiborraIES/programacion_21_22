﻿//Clase padre abstracta Personaje.
abstract class Personaje : IComparable<Personaje>
{
    protected string nombre;
    protected int vida;

    protected Personaje(string nombre, int vida)
    {
        this.nombre = nombre;
        if (vida >= 0 && vida <= 100)
            this.vida = vida;
    }

    public int CompareTo(Personaje otro)
    {
        return otro.vida.CompareTo(vida);
    }

    public string GetNombre()
    {
        return nombre;
    }

    public int GetVida() 
    { 
        return vida; 
    }

    public override string ToString()
    {
        return "Nombre: " + nombre + ". Vida: " + vida;
    }
}