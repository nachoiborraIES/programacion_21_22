﻿//Clase Guerreros hijo de Personaje
class Guerreros : Personaje
{
    private string material;
    public Guerreros(string nombre, int vida, string material) : 
        base(nombre, vida)
    {
        this.material = material;
    }

    public override string ToString()
    {
        return "Guerrero: " + base.ToString() + ". Material: " + material;
    }
}
