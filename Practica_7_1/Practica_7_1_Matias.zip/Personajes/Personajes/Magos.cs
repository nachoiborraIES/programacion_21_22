﻿//Clase Magos hijo de Personaje
class Magos : Personaje
{
    private int poder;
    public Magos(string nombre, int vida, int poder) : base(nombre, vida)
    {
        if(poder >= 1 && poder <= 10)
            this.poder = poder;
    }

    public override string ToString()
    {
        return "Mago: " + base.ToString() + ". Poder: " + poder;
    }
}
