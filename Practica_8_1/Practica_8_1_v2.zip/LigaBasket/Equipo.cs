﻿//Clase equipo con sus respectivos atributos y metodos, implementando tambien IComparable para ordenarse.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Equipo : IComparable<Equipo>
{
    private string nombre;
    private int ganados;
    private int perdidos;
    private int favor;
    private int contra;
    public Equipo(string nombre)
    {
        this.nombre = nombre;
        this.ganados = 0;
        this.perdidos = 0;
        this.favor = 0;
        this.contra = 0;
    }
    public string Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }public int Ganados
    {
        get { return ganados; }
        set { ganados = value; }
    }
    public int Perdidos
    {
        get { return perdidos; }
        set { perdidos = value; }
    }
    public int Favor
    {
        get { return favor; }
        set { favor = value; }
    }
    public int Contra
    {
        get { return contra; }
        set { contra = value; }
    }
    public void IncrementarGanados(int favor2, int contra2)
    {
        ganados++;
        favor += favor2;
        contra += contra2;
    }
    public void IncrementarPerdidos(int favor2, int contra2)
    {
        perdidos++;
        favor += favor2;
        contra += contra2;
    }
    public int CompareTo(Equipo otro)
    {
        if (ganados != otro.Ganados)
        {
            return otro.Ganados.CompareTo(ganados);
        }
        else if((otro.Favor-otro.Contra)!=(favor-contra))
        {
            return (otro.Favor - otro.Contra).CompareTo(favor - contra);
        }
        else if(otro.Favor!=favor)
        {
            return otro.Favor.CompareTo(favor);
        }
        return 0;
    }
}