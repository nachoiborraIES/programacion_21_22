﻿/* Programa principal del proyecto LigaBasket, cuya finalidad es leer y pasar a una lista los equipos
 * y sus respectivos partidos, para posteriormente agregar partidos, actualizar el documento que los
 * contiene y actualizar el fichero que los almacena tras todas sus comprobaciones.*/
using System;
using System.Collections;
class practica
{
    const string EQUIPOS = "equipos.txt";
    const string PARTIDOS = "partidos.txt";
    static void CargarEquipos(List<Equipo> equipos)
    {
        StreamReader fichero = File.OpenText(EQUIPOS);
        string linea;
        do
        {
            linea = fichero.ReadLine();
            if(linea!=null)
                equipos.Add(new Equipo(linea));
        }
        while (linea != null);
        fichero.Close();
    }
    static void CargarPartidos(List<Partido> partidos, List<Equipo> equipos)
    {
        string linea;
        string[] partes;
        StreamReader fichero = File.OpenText(PARTIDOS);
        linea = fichero.ReadLine();
        do
        {
            int posicion1 = 0;
            int posicion2 = 0;
            int cont=0;
            partes = linea.Split(';');
            for(int i=0;i<equipos.Count;i++)
            {
                if (partes[0] == equipos[i].Nombre)
                {
                    posicion1 = i;
                    cont++;
                }
                else if (partes[2] == equipos[i].Nombre)
                { 
                    posicion2 = i;
                    cont++;
                }
            }
            if(cont==2)
            {
                partidos.Add(new Partido(equipos[posicion1],
                Convert.ToInt32(partes[1]), equipos[posicion2],
                Convert.ToInt32(partes[3])));
                linea = fichero.ReadLine();
            }
        }
        while (linea != null);
        fichero.Close();
    }
    static void Puntuaciones(List<Partido> partidos, List<Equipo> equipos)
    {
        Equipo equipo1;
        Equipo equipo2;
        foreach (Partido p in partidos)
        {
            equipo1 = p.Equipo1;
            equipo2 = p.Equipo2;
            if (p.Puntos1 > p.Puntos2)
            {
                equipo1.IncrementarGanados(p.Puntos1,p.Puntos2);
                equipo2.IncrementarPerdidos(p.Puntos2, p.Puntos1);
            }
            else
            {
                equipo2.IncrementarGanados(p.Puntos2, p.Puntos1);
                equipo1.IncrementarPerdidos(p.Puntos1, p.Puntos2);
            }
        }
    }
    static void Rellenar(List<Partido> partidos, List<Equipo> equipos)
    {
        string NuevoPartido;
        do
        {
            Console.WriteLine("Introduce los datos del partido a añadir:");
            NuevoPartido = Console.ReadLine();
            if(NuevoPartido!="")
            {
                string[] partes = NuevoPartido.Split(';');
                int posicion1 = 0;
                int posicion2 = 0;
                int cont = 0;
                for (int i = 0; i < equipos.Count; i++)
                {
                    if (partes[0] == equipos[i].Nombre)
                    {
                        posicion1 = i;
                        cont++;
                    }
                    else if (partes[2] == equipos[i].Nombre)
                    {
                        posicion2 = i;
                        cont++;
                    }
                }
                if (cont == 2)
                {
                    if (Convert.ToInt32(partes[1]) >= 0
                    && Convert.ToInt32(partes[1]) <= 200
                    && Convert.ToInt32(partes[3]) >= 0
                    && Convert.ToInt32(partes[3]) <= 200
                    )
                    {
                        partidos.Add(new Partido(equipos[posicion1],
                        Convert.ToInt32(partes[1]), equipos[posicion2],
                        Convert.ToInt32(partes[3])));
                        Puntuaciones(partidos, equipos);
                    }
                    else
                        Console.WriteLine("Datos incorrectos.");
                }
                else
                    Console.WriteLine("Datos incorrectos.");
            }
            
        }
        while (NuevoPartido != "");
        Actualizar(partidos, equipos);
        Puntuaciones(partidos, equipos);
        ListadoOrdenado(partidos, equipos);
    }
    static void ListadoOrdenado(List<Partido> partidos, List<Equipo> equipos)
    {
        Console.WriteLine("-----------" +
            "-----------------" +
            "-------------------");
        int y;
        y= Console.CursorTop;
        equipos.Sort();
        Console.Write("| EQUIPO");
        Console.SetCursorPosition(20, y);
        Console.Write("| WIN");
        Console.SetCursorPosition(27, y);
        Console.Write("| LOSE");
        Console.SetCursorPosition(34, y);
        Console.WriteLine("|  +   |  - |");
        
        Console.WriteLine("-----------" +
            "-----------------" +
            "-------------------");
        foreach(Equipo e in equipos)
        {
            y = Console.CursorTop;
            Console.Write("|  "+e.Nombre);
            Console.SetCursorPosition(20, y);
            Console.Write("|  " + e.Ganados);
            Console.SetCursorPosition(27, y);
            Console.Write("|  " + e.Perdidos);
            Console.SetCursorPosition(34, y);
            Console.Write("|  " + e.Favor);
            Console.SetCursorPosition(41, y);
            Console.WriteLine(" "+e.Contra+" |");
        }
        Console.WriteLine("-----------" +
            "-----------------" +
            "-------------------");
    }
    static void Actualizar(List<Partido> partidos, List<Equipo> equipos)
    {
        using (StreamWriter File = new StreamWriter(PARTIDOS))
        { 
            foreach (Partido p in partidos) 
            {
                File.WriteLine(p);
            }
        }
    }
        static void Main()
    {
        List<Equipo> equipos = new List<Equipo>();
        List<Partido> partidos = new List<Partido>();
        CargarEquipos(equipos);
        CargarPartidos(partidos,equipos);
        Puntuaciones(partidos, equipos);
        Rellenar(partidos,equipos);
    }
}
