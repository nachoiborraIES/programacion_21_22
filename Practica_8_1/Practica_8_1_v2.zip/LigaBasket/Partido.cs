﻿//Clase partido con sus atributos,constructor, gets/sets y metodo to string.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Partido
{
    Equipo equipo1;
    Equipo equipo2;
    private int puntos1;
    private int puntos2;
    public Partido(Equipo equipo1, int puntos1, Equipo equipo2, int puntos2)
    {
        this.equipo1 = equipo1;
        this.equipo2 = equipo2;
        this.puntos1 = puntos1;
        this.puntos2 = puntos2;
    }
    public Equipo Equipo1
    {
        get { return equipo1; }
        set { equipo1 = value; }
    }
    public Equipo Equipo2
    {
        get { return equipo2; }
        set { equipo2 = value; }
    }
    public int Puntos1
    {
        get { return puntos1; }
        set { puntos1 = value; }
    }
    public int Puntos2
    {
        get { return puntos2; }
        set { puntos2 = value; }
    }
    public override string ToString()
    {
        return equipo1.Nombre+";" 
            + puntos1 + ";" +equipo2.Nombre+ ";" + Puntos2;
    }
}