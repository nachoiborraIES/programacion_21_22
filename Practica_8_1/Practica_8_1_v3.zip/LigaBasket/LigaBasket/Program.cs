﻿/*
 * Matías Agustín Piombo
 * 
 * Programa de una liga de basket para leer unos equipos dados en un 
 * fichero y para leer y añadir los partidos de estos equipos desde
 * otro fichero.
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        List<Equipo> equipos = new List<Equipo>();
        List<Partido> partidos = new List<Partido>();

        LeerEquipos(equipos);
        LeerPartidos(equipos, partidos);
        Mostrar(equipos);

        AnadirPartidos(equipos);
    }

    public static void LeerEquipos(List<Equipo> equipos)
    {
        string linea = "";

        using (StreamReader fichero = new StreamReader("Equipos.txt"))
        {
            while ((linea = fichero.ReadLine()) != null)
            {
                equipos.Add(new Equipo(linea));
            }
        }
    }

    public static void LeerPartidos(List<Equipo> equipos, 
        List<Partido> partidos)
    {
        
        Equipo local = null, visitante = null;
        string linea = "";
        string[] linPartido;
        int pLoc, pVis;

        using (StreamReader fichero = new StreamReader("Partidos.txt"))
        {
            while ((linea = fichero.ReadLine()) != null)
            {

                linPartido = linea.Split(';');
                local = new Equipo(linPartido[0]);
                visitante = new Equipo(linPartido[2]);
                pLoc = Convert.ToInt32(linPartido[1]);
                pVis = Convert.ToInt32(linPartido[3]);

                if (Existen(equipos, local, visitante)) 
                {
                    ActualizarPunt(partidos, equipos,
                        local, visitante, pLoc, pVis);
                }
                else
                    Console.WriteLine("Fallo al buscar el equipo.");
            }
        }
    }

    static bool Existen(List<Equipo> equipos, Equipo a, Equipo b)
    {
        bool exA = false, exB = false;

        foreach(Equipo e in equipos)
        {
            if(e.Nombre==a.Nombre)
                exA = true;
            if (e.Nombre == b.Nombre)
                exB = true;
        }

        if(exA && exB)
            return true;

        return false;
    }

    public static void ActualizarPunt(List<Partido> partidos,
        List<Equipo> equipos, Equipo local, Equipo visitante, 
        int pLoc, int pVis)
    {
        partidos.Add(new Partido(local, visitante, pLoc, pVis));

        if (pLoc > pVis)
            GanarPerder(equipos, local, visitante, pLoc, pVis);
        else
            GanarPerder(equipos, visitante, local, pVis, pLoc);
    }

    public static void GanarPerder(List<Equipo> equip, 
        Equipo gana, Equipo pierde, int pG, int pP)
    {
        foreach (Equipo e in equip)
        {
            if (e.Nombre == gana.Nombre)
            {
                if (pG != pP)
                    e.Ganados++;
                e.Favor += pG;
                e.Contra += pP;
            }

            if (e.Nombre == pierde.Nombre)
            {
                if (pG != pP)
                    e.Perdidos++;
                e.Favor += pP;
                e.Contra += pG;
            }
        }
    }

    public static void Mostrar(List<Equipo> equipos)
    {
        foreach (Equipo e in equipos)
        {
            Console.WriteLine(e.ToString());
        }
    }

    public static void AnadirPartidos(List<Equipo> equipos)
    {
        List<Partido> partidos = new List<Partido>();
        Equipo local, visitante;
        string partido, salida;
        int pLoc, pVis;
        string[] partes;
        Console.WriteLine("Añade tus partidos \n(Formato: " +
            "Equipo_Local;puntos_Local;Equipo_Visitante;puntos_Visitante) \n" +
            "(enter para finalizar): ");
        do
        {
            partido = Console.ReadLine();
            if (partido != "")
            {
                salida = "Partido añadido.";
                partes = partido.Split(';');

                if (partes.Length == 4)
                {
                    local = new Equipo(partes[0]);
                    visitante = new Equipo(partes[2]);
                    if (local.Nombre != visitante.Nombre)
                    {
                        if (Existen(equipos, local, visitante))
                        {
                            try
                            {
                                pLoc = Convert.ToInt32(partes[1]);
                                pVis = Convert.ToInt32(partes[3]);
                                if (pLoc >= 0 && pVis >= 0 &&
                                    pLoc <= 200 && pVis <= 200)
                                {
                                    ActualizarPunt(partidos, equipos,
                                        local, visitante, pLoc, pVis);
                                }
                                else
                                    salida = "Puntos incorrectos.";
                            }
                            catch (Exception e)
                            {
                                salida = "Puntuacion inválida.";
                            }
                        }
                        else
                            salida = "Fallo al buscar el equipo.";
                    }
                    else
                        salida = "Los equipos no pueden ser el mismo.";
                }
                else
                    salida="Formato Incorrecto.";


                Console.WriteLine(salida);
            }
        } while (partido != "");
        equipos.Sort();
        MostrarFormato(equipos);
        EscribirFichero(partidos);
    }

    public static void MostrarFormato(List<Equipo> equipos)
    {
        foreach (Equipo e in equipos)
        {
            Console.WriteLine(e.Formatear());
        }
    }

    public static void EscribirFichero(List<Partido> partidos)
    {
        if (File.Exists("Partidos.txt"))
        {
            using (StreamWriter fichero = 
                new StreamWriter("Partidos.txt", true))
            {
                foreach (Partido p in partidos)
                {
                    fichero.WriteLine(p.ToString());
                }
            }
        }
    }
}