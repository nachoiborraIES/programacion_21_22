﻿//Clase Partido para gestionar los partidos entre equipos.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class Partido
{
    private Equipo local;
    private Equipo visitante;
    private int puntosLoc;
    private int puntosVis;

    public Partido(Equipo local, Equipo visitante, int pLocal, int pVisitante)
    {
        this.local = local;
        this.visitante = visitante;
        this.puntosLoc = pLocal;
        this.puntosVis = pVisitante;
    }

    public int PuntosLocal { get { return puntosLoc; } 
        set { puntosLoc = value; } }
    public int PuntosVisitante { get { return puntosVis; } 
        set { puntosVis = value; } }

    public override string ToString()
    {
        return local.Nombre + ';' + puntosLoc + ';' + 
            visitante.Nombre + ';' + puntosVis;
    }
}