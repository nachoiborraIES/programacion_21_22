﻿//Clase Equipo para gestionar los equipos de baloncesto.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class Equipo : IComparable<Equipo>
{
    private string nombre;
    private int ganados;
    private int perdidos;
    private int favor;
    private int contra;

    public Equipo(string name)
    {
        this.nombre = name;
        ganados = 0;
        perdidos = 0;
        favor = 0;
        contra = 0;
    }
    public string Nombre { get { return nombre; } set { nombre = value; } }
    public int Ganados { get { return ganados; } set { ganados = value; } }
    public int Perdidos { get { return perdidos; } set { perdidos = value; } }
    public int Favor { get { return favor; } set { favor = value; } }
    public int Contra { get { return contra; } set { contra = value; } }

    public int DiferenciaPuntos()
    {
        return favor - contra;
    }

    public int CompareTo(Equipo otro)
    {
        if (otro.Ganados != this.ganados)
            return otro.Ganados.CompareTo(this.ganados);
        else
        {
            if (otro.DiferenciaPuntos() != DiferenciaPuntos())
                return otro.DiferenciaPuntos().CompareTo(DiferenciaPuntos());
            else
            {
                if(otro.Favor!=favor)
                    return otro.Favor.CompareTo(favor);
            }
        }
        return 0;
    }

    public override string ToString() 
    {
        return "Nombre: " + nombre + ". \n  Partidos: \n    Ganados: " + 
            ganados + ". \n    Perdidos: " + perdidos + ". \n  Puntos: " +
            "\n    A favor: " + favor + ". \n    En contra: " + contra + ".\n"; 
    }

    public string Formatear()
    {
        return nombre + Espaciado(nombre, 25) +
            ganados + Espaciado(ganados.ToString(), 8) +
            perdidos + Espaciado(perdidos.ToString(), 8) +
            favor + Espaciado(favor.ToString(), 10) +
            contra + Espaciado(contra.ToString(), 10);
    }

    public string Espaciado(string campo, int cantidad)
    {
        string espacios="";

        for (int i = 0; i < cantidad - campo.Length; i++)
        {
            espacios += " ";
        }

        return espacios;
    }
}
