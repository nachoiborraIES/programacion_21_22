﻿using System;
using System.Collections.Generic;
using System.IO;
/*
    Clase principal donde se ejecuta el programa.
*/
class Principal
{
    static void Main()
    {
        
        List<Equipo> equipos= new List<Equipo>();
        List<Partido> partidos= new List<Partido>();


        CrearListaEquipos(equipos);

        CrearListaPartidos(partidos, equipos);

        AñadirNuevosPartidos(equipos, partidos);
        Console.Clear();

        Ranking(equipos);

       GuardarPartidos(partidos);

    }

    static Equipo BuscarEquipo(string nombre, List<Equipo> equipos, int puntos,
       int puntoscontrario)
    {
        Equipo aux=null;
        for(int i=0; i<equipos.Count; i++)
        {
            if(equipos[i].Nombre == nombre)
            {
               aux= equipos[i];
               equipos[i].CalcularPuntos(puntos, puntoscontrario);
            }
        }

        return aux;
    }

    static void CrearListaEquipos(List<Equipo> equipos)
    {
        string linea = " ";

        using (StreamReader fichero = new StreamReader("Equipos.txt"))
        {

            do
            {
                linea = fichero.ReadLine();

                if (linea != null)
                {
                    equipos.Add(new Equipo(linea));
                }


            } while (linea != null);
        }
    }

    static void CrearListaPartidos(List<Partido> partidos,
        List<Equipo> equipos)
    {
        string linea = " ";
        int puntoslocal = 0, puntosvisitante = 0;
        Equipo equipolocal, equipovisitante;

        using (StreamReader fichero = new StreamReader("Partidos.txt"))
        {
            
            do
            {
                linea = fichero.ReadLine();

                if (linea != null)
                {
                    string[] partidoseparado = linea.Split(';');

                    if (partidoseparado.Length == 4)
                    {
                        puntoslocal = Convert.ToInt32(partidoseparado[1]);
                        
                        puntosvisitante = Convert.ToInt32(partidoseparado[3]);

                        equipolocal = BuscarEquipo(partidoseparado[0],
                            equipos, puntoslocal, puntosvisitante);
                        equipovisitante = BuscarEquipo(partidoseparado[2],
                            equipos, puntosvisitante, puntoslocal);
                        


                        partidos.Add(new Partido(equipolocal, puntoslocal,
                            equipovisitante, puntosvisitante));

                    }
                }


            } while (linea != null);
        }
    }

    static void AñadirNuevosPartidos(List<Equipo> equipos,
        List<Partido> partidos)
    {
        string linea="";
        string[] lineaSeparado;
        int puntoslocal = 0, puntosvisitante = 0;
        bool cerrar = false;
        Equipo local, visitante;
        do
        {
            Console.WriteLine("Escribe el partido");
            linea= Console.ReadLine();

            if(linea != null && linea != " " && linea != "")
            {
                lineaSeparado = linea.Split(';');

                if (lineaSeparado.Length == 4)
                {
                    puntoslocal = Convert.ToInt32(lineaSeparado[1]);
                    puntosvisitante = Convert.ToInt32(lineaSeparado[3]);
                    if (puntoslocal >= 0 && puntoslocal <= 200 &&
                            puntosvisitante >= 0 && puntosvisitante <= 200)
                    {
                        local = BuscarEquipo(lineaSeparado[0], equipos,
                            puntoslocal, puntosvisitante);
                        visitante = BuscarEquipo(lineaSeparado[2], equipos,
                            puntosvisitante, puntoslocal);

                        if (local != null && visitante != null)
                        {
                            partidos.Add(new Partido(local,
                                puntoslocal, visitante,
                                puntosvisitante));
                        }
                        else
                        {
                            Console.WriteLine("Partido incorrecto");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Partido incorrecto");
                    }
                }
                else
                {
                    Console.WriteLine("Partido incorrecto");
                }
            }
            else
            {
                cerrar = true;
            }
  
        } while (!cerrar);
    }

    static void Ranking(List<Equipo> equipos)
    {
        int maxlength = 0;
        string aux="";
        for(int i=0; i<equipos.Count; i++)
        {
            aux= equipos[i].Nombre;

            if(aux.Length > maxlength)
            {
                maxlength = aux.Length;
            }
        }

        equipos.Sort();

        Console.WriteLine("Nombre equipo    ganados" +
            "    perdidos    puntos_favor    puntos_contra");

        foreach(Equipo equipo in equipos)
        {
            Console.WriteLine(equipo.ATabla(maxlength));
        }
    }

    static void GuardarPartidos(List<Partido> partidos)
    {
        using (StreamWriter fichero = new StreamWriter("Partidos.txt"))
        {
            for(int i=0; i<partidos.Count; i++)
            {
                fichero.WriteLine(partidos[i].ToArchivo());
            }
        }
    }

}