﻿using System;
using System.Collections.Generic;

/*
    Clase partido donde se almacena la informacion de los partidos de
    la lista.
*/

class Partido
{
    private Equipo equipoLocal;
    private Equipo equipoVisitante;
    private int puntosLocal;
    private int puntosVisitante;

    public Partido(Equipo equipoLocal, int puntosLocal, Equipo equipoVisitante, int puntosVisitante)
    {
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.puntosLocal = puntosLocal;
        this.puntosVisitante = puntosVisitante;
    }

    public string ToArchivo()
    {
        return equipoLocal+";"+puntosLocal+ ";" + puntosVisitante+ ";"+equipoVisitante;
    }
}