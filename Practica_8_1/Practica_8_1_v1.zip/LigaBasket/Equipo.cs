﻿using System;
using System.Collections.Generic;

/*
    Clase Equipo donde se almacena la informacion de los equipos,
para ordenarlos en el ranking.
*/
class Equipo : IComparable<Equipo>
{
    private string nombre;
    private int partidosGanados;
    private int partidosPerdidos;
    private int puntosFavor;
    private int puntosContra;
    
    public string Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }

    public int PartidosGanados
    {
        get { return partidosGanados; }
    }

    public int PuntosContra
    {
        get { return puntosContra; }
    }

    public int PartidosPerdidos
    {
        get { return partidosPerdidos;}
    }

    public int PuntosFavor
    {
        get { return puntosFavor; }
    }

    public Equipo(string nombre)
    {
        this.nombre = nombre;
        this.partidosGanados = 0;
        this.partidosPerdidos = 0;
        this.puntosFavor = 0;
        this.puntosContra = 0;
    }

    public void CalcularPuntos(int puntosanotados, int puntoscontrario)
    {
        puntosFavor += puntosanotados;
        puntosContra += puntoscontrario;
        if(puntosanotados > puntoscontrario)
        {
            partidosGanados++;
        }
        else if(puntosanotados < puntoscontrario)
        {
            partidosPerdidos++;
        }
    }

    public string ATabla(int nespacios)
    {
        int rep;
        string nombreFormateado=Nombre;
        rep= nespacios-Nombre.Length;
        for(int i=0;i<rep;i++)
        {
            nombreFormateado += " ";
        }

        if(puntosFavor < 100)
        {
            return nombreFormateado + "    " + partidosGanados + "         " + partidosPerdidos + "           " + puntosFavor + "               " + puntosContra;
        }
        else
        {
            return nombreFormateado + "    " + partidosGanados + "         " + partidosPerdidos + "          " + puntosFavor + "              " + puntosContra;
        }

        
    }

    public int CompareTo(Equipo? other)
    {
        if(other.PartidosGanados > this.PartidosGanados)
        {
            return 1;
        }
        else if(other.PartidosGanados < this.PartidosGanados)
        {
            return -1;
        }
        else
        {
            if(other.PuntosFavor-other.PuntosContra > this.PuntosFavor - this.PuntosContra)
            {
                return 1;
            }
            else if (other.PuntosFavor - other.PuntosContra < this.PuntosFavor - this.PuntosContra)
            {
                return -1;
            }
            else
            {
                if(other.PuntosFavor> this.PuntosFavor)
                {
                    return 1;
                }
                else if(other.PuntosFavor < this.PuntosFavor)
                {
                    return -1;
                }
                else
                {
                    return 0;
                }
            }
        }
    }
}