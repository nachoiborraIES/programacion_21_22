﻿using System;

/*
 * Configuración general del juego
 */
class Configuracion
{
    public const int ANCHO_PANTALLA = 100;
    public const int ALTO_PANTALLA = 15;
    public const int PAUSA_BUCLE = 70;
    public const int MAX_DISPAROS = 7;
    public const int VIDAS_INICIALES = 3;
    public const int PUNTOS_ENEMIGO = 50;
    public static int PROBABILIDAD = 500;

    public static void CambiarProbabilidad(int prob)
    {
        PROBABILIDAD = prob;
    }

    public static void Reset()
    {
        PROBABILIDAD = 500;
    }

    public static Random r = new Random();
}
