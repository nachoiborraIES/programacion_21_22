﻿using System;

/* Nave principal del juego. Subtipo de Sprite */
class Nave : Sprite
{

    private Disparo[] disparos;

    private int vidas;

    private int puntos;

    public Nave()
    : this(Configuracion.ANCHO_PANTALLA - 80, Configuracion.ALTO_PANTALLA / 2)
    {
    }

    public Nave(int cx, int cy)
    {
        vidas = Configuracion.VIDAS_INICIALES;
        puntos = 0;
        disparos = new Disparo[Configuracion.MAX_DISPAROS];
        for (int i = 0; i < disparos.Length; i++)
        {
            disparos[i] = new Disparo();
        }
        imagen = ">";
        x = cx;
        y = cy;
    }


    public int GetVidas()
    {
        return vidas;
    }

    public int GetPuntos()
    {
        return puntos;
    }

    public void SetVidas(int vidas)
    {
        this.vidas = vidas;
    }

    public void SetPuntos(int puntos)
    {
        this.puntos = puntos;
    }

    public Disparo[] GetDisparos()
    {
        return disparos;
    }

    public void Disparar()
    {
        int n = 0;
        bool encontrado = false;

        while (n < disparos.Length && !encontrado)
        {
            if (!disparos[n].GetActivo())
            {
                disparos[n].MoverA(x + 1, y);
                disparos[n].SetActivo(true);
                encontrado = true;
            }
            n++;
        }
    }

    public void MoverDisparos()
    {
        for (int i = 0; i < disparos.Length; i++)
        {
            if (disparos[i].GetActivo())
            {
                if (disparos[i].GetX() < Configuracion.ANCHO_PANTALLA - 1)
                    disparos[i].MoverA(disparos[i].GetX() + 1,
                        disparos[i].GetY());
                else
                {
                    disparos[i].SetActivo(false);
                    disparos[i].MoverA(x, y);
                }
            }
        }
    }

    public override void Dibujar()
    {
        Console.ForegroundColor = ConsoleColor.White;
        base.Dibujar();
        foreach (Disparo d in disparos)
        {
            d.Dibujar();
        }
        Console.ResetColor();
    }

    public void ComprobarColisionConOvni(Enemigo o)
    {
        if (o.GetActivo())
        {
            foreach (Disparo d in disparos)
            {
                if (d.GetActivo() && o.GetActivo() && d.ColisionaCon(o))
                {
                    o.SetActivo(false);
                    o.MoverA(Enemigo.INI_X, Enemigo.INI_Y);
                    d.SetActivo(false);
                    d.MoverA(x, y);
                    puntos += Configuracion.PUNTOS_ENEMIGO;
                }
            }
        }
    }


}