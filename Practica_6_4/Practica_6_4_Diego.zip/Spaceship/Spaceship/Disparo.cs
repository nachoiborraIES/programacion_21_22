﻿using System;

/* Clase para representar los disparos de las naves */
class Disparo : Sprite
{
    private bool activo;

    public Disparo()
    {
        activo = false;
        imagen = "-";
    }

    public void SetActivo(bool a)
    {
        activo = a;
    }

    public bool GetActivo()
    {
        return activo;
    }

    public override void Dibujar()
    {
        if (activo)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            base.Dibujar();
            Console.ResetColor();
        }
    }
}
