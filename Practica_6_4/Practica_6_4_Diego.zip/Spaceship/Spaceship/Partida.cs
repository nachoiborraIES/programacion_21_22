﻿using System;

/*
 * Clase para gestionar la partida principal
 */
class Partida
{
    public void Lanzar()
    {
        ConsoleKeyInfo tecla = new ConsoleKeyInfo();
        Nave nave = new Nave();
        Enemigo[] o = new Enemigo[100];
        for (int i = 0; i < o.Length; i++)
        {
            o[i] = new Enemigo();
        }



        do
        {
            for (int i = 0; i < o.Length; i++)
            {
                o[i].Dibujar();
            }
            nave.Dibujar();


            Thread.Sleep(Configuracion.PAUSA_BUCLE);

            if (Console.KeyAvailable)
            {
                while (Console.KeyAvailable)
                {
                    tecla = Console.ReadKey();
                }
                if (tecla.Key == ConsoleKey.UpArrow)
                {
                    nave.MoverA(nave.GetX(), nave.GetY() - 1);
                }
                else if (tecla.Key == ConsoleKey.DownArrow)
                {
                    nave.MoverA(nave.GetX(), nave.GetY() + 1);
                }
                else if (tecla.Key == ConsoleKey.Spacebar)
                {
                    nave.Disparar();
                }
            }

            nave.MoverDisparos();

            for (int i = 0; i < o.Length; i++)
            {
                if (o[i].GetActivo())
                    o[i].Mover();
                else
                    o[i].IntentarActivacion(nave);
            }

            for (int i = 0; i < o.Length; i++)
            {
                nave.ComprobarColisionConOvni(o[i]);
                if (o[i].GetActivo() && o[i].ColisionaCon(nave))
                {
                    o[i].SetActivo(false);
                    nave.SetVidas(nave.GetVidas() - 1);
                }
            }




            ActualizarHUD(nave);
        }
        while (tecla.Key != ConsoleKey.Escape && nave.GetVidas() > 0);

        Configuracion.Reset();

        Console.Clear();


    }




    public void ActualizarHUD(Nave nave)
    {
        Console.SetCursorPosition(Configuracion.ANCHO_PANTALLA - 13, 0);
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Puntos: {0}", nave.GetPuntos());
        Console.ResetColor();

        Console.SetCursorPosition(0, 1);
        Console.ForegroundColor = ConsoleColor.Yellow;
        for (int i = 0; i < Configuracion.ANCHO_PANTALLA; i++)
        {
            Console.Write("-");
        }

        Console.SetCursorPosition(0, Configuracion.ALTO_PANTALLA - 2);
        for (int i = 0; i < Configuracion.ANCHO_PANTALLA; i++)
        {
            Console.Write("-");
        }

        Console.SetCursorPosition(Configuracion.ANCHO_PANTALLA - 13,
            Configuracion.ALTO_PANTALLA - 1);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write("Vidas: {0}", nave.GetVidas());

        Console.ResetColor();
    }
}

