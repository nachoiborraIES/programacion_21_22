﻿using System;

/*
 * Clase para la pantalla de bienvenida del juego
 */
class Bienvenida
{
    private bool salir;

    public void Lanzar()
    {

        Console.ForegroundColor = (ConsoleColor)Configuracion.r.Next(1, 16);

        Console.Title = "ASCII Art";

        string title = @"


                     ___________  ___  _____  _____ _____ _   _ ___________ 
                    /  ___| ___ \/ _ \/  __ \|  ___/  ___| | | |_   _| ___ \
                    \ `--.| |_/ / /_\ \ /  \/| |__ \ `--.| |_| | | | | |_/ /
                     `--. \  __/|  _  | |    |  __| `--. \  _  | | | |  __/ 
                    /\__/ / |   | | | | \__/\| |___/\__/ / | | |_| |_| |    
                    \____/\_|   \_| |_/\____/\____/\____/\_| |_/\___/\_| ";



        Console.WriteLine(title);
        Console.WriteLine("");
        string t = "Pulsa Espacio para iniciar el juego";
        Console.SetCursorPosition((Console.WindowWidth - t.Length) / 2,
            Console.CursorTop);
        Console.WriteLine(t);

        Console.ResetColor();

        ConsoleKeyInfo tecla = Console.ReadKey();
        if (tecla.Key == ConsoleKey.Escape)
            salir = true;
        else if (tecla.Key == ConsoleKey.Spacebar)
            salir = false;
        else
        {
            Console.WriteLine("Opción incorrecta. Saliendo del juego");
            salir = true;
        }
    }

    public bool GetSalir()
    {
        return salir;
    }
}

