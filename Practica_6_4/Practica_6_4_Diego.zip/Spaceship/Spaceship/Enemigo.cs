﻿using System;

/* Clase que se encarga del comportamiento de los enemigos*/
class Enemigo : Sprite
{
    public const int INI_X = 97;
    public static int INI_Y;

    public Enemigo()
    {
        imagen = "X";
        activo = false;
    }

    private bool activo;


    public bool GetActivo()
    {
        return activo;
    }

    public void SetActivo(bool a)
    {
        activo = a;
    }


    public void IntentarActivacion(Nave nave)
    {
        int dif = Configuracion.r.Next(0, Configuracion.PROBABILIDAD);


        if (nave.GetPuntos() >= 500 && nave.GetPuntos() < 1500)
        {
            Configuracion.CambiarProbabilidad(100);
        }

        else if (nave.GetPuntos() >= 1500 && nave.GetPuntos() < 4000)
        {
            Configuracion.CambiarProbabilidad(10);
        }

        else if (nave.GetPuntos() > 4000)
        {
            Configuracion.CambiarProbabilidad(1);
        }

        if (dif == 0)
        {
            INI_Y = Configuracion.r.Next(2, Configuracion.ALTO_PANTALLA - 2);
            activo = true;
            x = INI_X;
            y = INI_Y;
        }


    }

    public void Mover()
    {
        if (GetX() > 0)
            MoverA(x - 1, y);
        else
        {
            MoverA(INI_X, INI_Y);
            SetActivo(false);
        }
    }

    public override void Dibujar()
    {
        if (activo)
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            base.Dibujar();
            Console.ResetColor();
        }
    }

}
