﻿using System;
/*Clase padre que representa los distintos tipos de sprites del juego*/
class Sprite
{
    protected int x;
    protected int y;
    protected string imagen;

    public int GetX()
    {
        return x;
    }

    public int GetY()
    {
        return y;
    }

    public string GetImagen()
    {
        return imagen;
    }

    public void SetX(int cx)
    {
        x = cx;
    }

    public void SetY(int cy)
    {
        y = cy;
    }

    public void SetImagen(string img)
    {
        imagen = img;
    }

    public void MoverA(int cx, int cy)
    {
        if (cx >= 0 && cx <= Configuracion.ANCHO_PANTALLA - 1 &&
            cy >= 1 && cy < Configuracion.ALTO_PANTALLA - 1)
        {
            Console.SetCursorPosition(x, y);
            for (int i = 0; i < 1; i++)
                Console.Write(" ");

            SetX(cx);
            SetY(cy);
        }
    }

    public virtual void Dibujar()
    {
        Console.SetCursorPosition(x, y);
        Console.Write(imagen);
    }

    public bool ColisionaCon(Sprite s)
    {
        int tam1 = GetImagen().Length;
        int tam2 = s.GetImagen().Length;

        bool colisionX = (GetX() <= s.GetX() && GetX() + tam1 >= s.GetX()) ||
                         (s.GetX() <= GetX() && s.GetX() + tam2 >= GetX());
        bool colisionY = GetY() == s.GetY();

        return colisionX && colisionY;
    }
}
