﻿/*
 * Programa principal de Spaceship
 * Se centra en la lógica de alternar entre pantalla de partida y de bienvenida.
 * Este juego nos permitirá controlar una nave en vertical para eliminar a unos 
 * enemigos que aparecerán de forma aleatoria aumentando su probabilidad al incrementar 
 * los puntos que conseguiremos al matarlos y que desaparecerán una vez muertos 
 * o bien al llegar al fondo de la pantalla.
 * 
 */

Bienvenida b;

do
{
    b = new Bienvenida();
    b.Lanzar();
    if (!b.GetSalir())
    {
        Console.Clear();
        Partida p = new Partida();
        p.Lanzar();
        Console.Clear();
    }
} while (!b.GetSalir());

