﻿using System;
/*
 * Configuración general del juego
 */
class Configuracion
{
    public const int ANCHO_PANTALLA = 100;
    public const int ALTO_PANTALLA = 15;
    public const int PAUSA_BUCLE = 50;
    public const int PROBABILIDAD_ENEMIGO = 1;
    public static Random r = new Random();
    public const int VIDAS_INICIALES = 3;
    public const int PUNTOS_ENEMIGO = 10;
}