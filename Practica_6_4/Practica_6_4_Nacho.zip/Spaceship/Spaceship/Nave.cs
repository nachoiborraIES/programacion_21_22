﻿using System;
/* Nave del juego. Subtipo de Sprite */
class Nave : Sprite
{
    Disparo[] disparos;

    private int vidas;

    private int puntos;
    public Nave() : this(5, 6)
    {
    }

    public Nave(int cx, int cy)
    {
        vidas = Configuracion.VIDAS_INICIALES;
        puntos = 0;
        disparos = new Disparo[5];
        for (int i = 0; i < disparos.Length; i++)
        {
            disparos[i] = new Disparo();
        }
        imagen = ">";
        x = cx;
        y = cy;
    }

    public int GetVidas()
    {
        return vidas;
    }

    public int GetPuntos()
    {
        return puntos;
    }

    public void SetVidas(int vidas)
    {
        this.vidas = vidas;
    }

    public void SetPuntos(int puntos)
    {
        this.puntos = puntos;
    }
    public Disparo[] GetDisparos()
    {
        return disparos;
    }

    public void Disparar()
    {
        bool encontrado = false;
        int i = 0;
        while (i < disparos.Length && !encontrado)
        {
            if (!disparos[i].GetActivo())
            {
                disparos[i].MoverA(x - 1, y);
                disparos[i].SetActivo(true);
                encontrado = true;
            }
            i++;
        }
    }

    public void MoverDisparo()
    {
        foreach (Disparo disparo in disparos)
        {
            if (disparo.GetActivo())
            {
                if (disparo.GetX() < Configuracion.ANCHO_PANTALLA - 1)
                {
                    disparo.MoverA(disparo.GetX() + 1, disparo.GetY());
                }  
                else
                {
                    disparo.SetActivo(false);
                    disparo.MoverA(x, y);
                }
            }
        }
    }

    public override void Dibujar()
    {
        foreach (Disparo disparo in disparos)
        {
            Console.ForegroundColor = ConsoleColor.White;
            base.Dibujar();
            disparo.Dibujar();
            Console.ResetColor();
        }
    }
}