﻿using System;

/*
 * Clase para la pantalla de bienvenida del juego
 */
class Bienvenida
{
    bool salir;

    public void Lanzar()
    {

        Console.ForegroundColor = ConsoleColor.Red;
        for (int i = 0; i < 5; i++)
            Console.WriteLine();
        Console.WriteLine("-.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.-");
        Console.WriteLine("-.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.-");
        Console.WriteLine("");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("BIENVENIDO A");
        Console.WriteLine("");
        Console.ForegroundColor = ConsoleColor.DarkRed;
        Console.Write("S");
        Console.ForegroundColor = ConsoleColor.DarkBlue;
        Console.Write("P");
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.Write("A");
        Console.ForegroundColor = ConsoleColor.Gray;
        Console.Write("C");
        Console.ForegroundColor = ConsoleColor.White;
        Console.Write("E");
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.Write("S");
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write("H");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write("I");
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("P");
        Console.WriteLine("");
        Console.WriteLine("");
        Console.WriteLine("Pulse Espacio para jugar o Esc para salir");
        Console.WriteLine("");
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("|.||.||.||.||.||.||.||.||.||.||.||.||.||.||.||.||.||.||.||.|");
        Console.WriteLine("|.||.||.||.||.||.||.||.||.||.||.||.||.||.||.||.||.||.||.||.|");

        Console.ResetColor();

        ConsoleKeyInfo tecla = Console.ReadKey();
        if (tecla.Key == ConsoleKey.Escape)
            salir = true;
        else if (tecla.Key == ConsoleKey.Spacebar)
            salir = false;
        else
        {
            Console.WriteLine("Opción incorrecta. Saliendo del juego");
            salir = true;
        }
    }

    public bool GetSalir()
    {
        return salir;
    }
}
