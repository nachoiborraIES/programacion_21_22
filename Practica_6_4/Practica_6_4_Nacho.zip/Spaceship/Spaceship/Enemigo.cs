﻿using System;
/* Enemigos del juego. Subtipo de Sprite */
class Enemigo : Sprite
{
    protected bool activo;

    public Enemigo()
    {
    }

    public Enemigo(int cx, int cy)
    {
        activo = false;
        x = cx;
        y = cy;
        imagen = "X";
    }
    public bool GetActivo()
    {
        return activo;
    }
    public void SetActivo(bool a)
    {
        activo = a;
    }

    public override void Dibujar()
    {
        if (activo)
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            base.Dibujar();
            Console.ResetColor();
        }
    }
    public void IntentarActivar(Nave nave)
    {
        int numero = Configuracion.r.Next(0, 1000);
        int probabilidad = Configuracion.PROBABILIDAD_ENEMIGO;

        if(nave.GetPuntos() >= probabilidad * 100)
        {
            probabilidad = probabilidad * 2;
        }

        if (numero < probabilidad)
        {
            activo = true;
        }
    }
    public void Mover()
    {
        if (x > 0)
            MoverA(x - 1, y);

        else
        {
            activo = false;
            MoverA(Configuracion.ANCHO_PANTALLA - 1, y);
        }
    }
    public void ComprobarColisionConNave(Nave nave, Enemigo[] enemigos)
    {
        int numero = Configuracion.r.Next(1, 14);
        int j = 0;
        while (j < enemigos.Length)
        {
            if (enemigos[j].GetActivo() && nave.ColisionaCon(enemigos[j]))
            {
                enemigos[j].SetActivo(false);
                enemigos[j].MoverA(Configuracion.ANCHO_PANTALLA - 1, numero);
                nave.SetVidas(nave.GetVidas() - 1);
                nave.MoverA(5, 6);
            }
            j++;
        }
        Disparo[] disparosNave = nave.GetDisparos();

        foreach (Disparo d in disparosNave)
        {
            if (d.GetActivo())
            {
                foreach (Enemigo e in enemigos)
                {
                    if (e.GetActivo() && e.ColisionaCon(d))
                    {
                        e.SetActivo(false);
                        e.MoverA(Configuracion.ANCHO_PANTALLA - 1, numero);
                        d.SetActivo(false);
                        d.MoverA(nave.GetX(), nave.GetY());
                        
                        nave.SetPuntos(nave.GetPuntos() + Configuracion.PUNTOS_ENEMIGO);
                    }
                }
            }
        }
    }
}