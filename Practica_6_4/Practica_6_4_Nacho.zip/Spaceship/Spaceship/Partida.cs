﻿using System;
/*
 * Clase para gestionar la partida principal
 */
class Partida
{
    public void Lanzar()
    {
        Console.CursorVisible = false;

        ConsoleKeyInfo tecla = new ConsoleKeyInfo();
        Nave nave = new Nave();
        Enemigo[] enemigos = new Enemigo[200];
        for (int i = 0; i < enemigos.Length; i++)
        {
            int numero = Configuracion.r.Next(1, 14);
            enemigos[i] = new Enemigo(Configuracion.ANCHO_PANTALLA - 1, numero);
        }

        do
        {
            nave.Dibujar();
            for (int i = 0; i < enemigos.Length; i++)
            {
                enemigos[i].Dibujar();
            }
                
            Thread.Sleep(Configuracion.PAUSA_BUCLE);

            if (Console.KeyAvailable)
            {
                while (Console.KeyAvailable)
                {
                    tecla = Console.ReadKey(true);
                }
                if (tecla.Key == ConsoleKey.DownArrow)
                {
                    nave.MoverA(nave.GetX(), nave.GetY() + 1);
                }
                else if (tecla.Key == ConsoleKey.UpArrow)
                {
                    nave.MoverA(nave.GetX(), nave.GetY() - 1);
                }
                else if (tecla.Key == ConsoleKey.Spacebar)
                {
                    nave.Disparar();
                }
            }

            for(int i = 0;i < enemigos.Length; i++)
            {
                if (enemigos[i].GetActivo())
                {
                    enemigos[i].Mover();
                }
                else
                {
                    enemigos[i].IntentarActivar(nave);
                }
                enemigos[i].ComprobarColisionConNave(nave, enemigos);
            }
            
            nave.MoverDisparo();

            ActualizarHUD(nave);
        }
        while (tecla.Key != ConsoleKey.Escape && nave.GetVidas() > 0);

        Console.Clear();
    }

    public void ActualizarHUD(Nave nave)
    {
        Console.SetCursorPosition(Configuracion.ANCHO_PANTALLA - 20, 0);
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write("Puntos: {0}", nave.GetPuntos());

        Console.SetCursorPosition(Configuracion.ANCHO_PANTALLA - 20, Configuracion.ALTO_PANTALLA - 1);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write("Vidas: {0}", nave.GetVidas());

        Console.ResetColor();
    }
}