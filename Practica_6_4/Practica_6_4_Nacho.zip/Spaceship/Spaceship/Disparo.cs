﻿using System;
/* Clase para representar los disparos de las naves. Subtipo de Sprite */
class Disparo : Sprite
{
    bool activo;

    public Disparo()
    {
        activo = false;
        imagen = "-";
    }

    public void SetActivo(bool a)
    {
        activo = a;
    }

    public bool GetActivo()
    {
        return activo;
    }

    public override void Dibujar()
    {
        if (activo)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            base.Dibujar();
            Console.ResetColor();
        }
    }
}