﻿using System;

/*
 * Clase para la pantalla de bienvenida del juego
 */
class Bienvenida
{
    bool salir;
    public void Lanzar()
    {
        int windowW = Configuracion.ANCHO_PANTALLA;
        int windowH = Configuracion.ALTO_PANTALLA;
        string[] nombre = DibujarNombre(), ovni = DibujarOvni(),
            cielo = DibujarCielo();

        Console.ForegroundColor = ConsoleColor.DarkRed;

        for (int i = 0; i < nombre.Length; i++)
        {
            Console.SetCursorPosition(windowW / 2 - nombre[i].Length / 2 + i,
                windowH / 2 + i - 2);
            Console.WriteLine(nombre[i]);
        }

        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.SetCursorPosition(windowW - 27, 1);
        Console.WriteLine("Klavier Navarro - 1º DAM B");

        Console.ForegroundColor = ConsoleColor.Green;
        Console.SetCursorPosition(windowW / 2 - 20, windowH / 2 + 7);
        Console.WriteLine("Pulse Espacio para jugar o Esc para salir");
        Console.ResetColor();

        Console.ForegroundColor = ConsoleColor.DarkYellow;
        for (int i = 0; i < ovni.Length; i++)
        {
            Console.SetCursorPosition(2, windowH / 2 - 2 + i);
            Console.WriteLine(ovni[i]);
        }
        Console.ResetColor();

        Console.ForegroundColor = ConsoleColor.DarkBlue;
        for (int i = 0; i < cielo.Length; i++)
        {
            Console.SetCursorPosition(windowW -  28, windowH / 2 - 4 + i);
            Console.WriteLine(cielo[i]);
        }
        Console.ResetColor();

        ConsoleKeyInfo tecla = Console.ReadKey();
        if (tecla.Key == ConsoleKey.Escape)
            salir = true;
        else if (tecla.Key == ConsoleKey.Spacebar)
            salir = false;
        else
        {
            Console.WriteLine("Opción incorrecta. Saliendo del juego");
            salir = true;
        }
    }

    public string[] DibujarNombre()
    {
        string[] nombre =
         {
            "      _/_/_/                                                    _/        _/           ",
            "   _/        _/_/_/      _/_/_/    _/_/_/    _/_/      _/_/_/  _/_/_/        _/_/_/    ",
            "    _/_/    _/    _/  _/    _/  _/        _/_/_/_/  _/_/      _/    _/  _/  _/    _/   ",
            "       _/  _/    _/  _/    _/  _/        _/            _/_/  _/    _/  _/  _/    _/    ",
            "_/_/_/    _/_/_/      _/_/_/_/  _/_/_/    _/_/_/  _/_/_/    _/    _/  _/  _/_/_/       ",
            "         _/                                                              _/            ",
            "        _/                                                              _/             "
        };

        return nombre;
    }
    public string[] DibujarOvni()
    {
        string[] ovni =
        {
        "       _.---._",
        "     .'       '.",
        " _.-~===========~-._",
        "(___________________)",
        "      \\_______/"
        };

        return ovni;
    }
    public string[] DibujarCielo()
    {
        string[] cielo =
        {
            "   °   .:  ・  .   .    .*  °",
            ".    *  ・. .  :   .:¨   *・ °",
            "  *.:.    :.  :   ・°.     °  ",
            "  .:¨   * .  . ° *  ° .  ・   ",
            "     .  ° . .  *  ・ ° .  ・ *",
            "  ° . .  . .  * ・ *   ・ *  ° ",
            "   ・ * .  *  ・ ° .  ° . .  * ",
            "*   ° .・ ° .   *  .   . ・ ¨. ",
            "     *.:.    :.  :   ・°.   °  ",
            " °   .:  ・ " +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            "" +
            " . *  :.    .*  °"

        };
        return cielo;
    }
    public bool GetSalir()
    {
        return salir;
    }
}