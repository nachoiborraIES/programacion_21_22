﻿using System;

/*
 * Clase para ajustar los parámetros importantes del juego mediante constantes.
 */
class Configuracion
{
    public const int ANCHO_PANTALLA = 150;
    public const int ALTO_PANTALLA = 15;
    public const int PAUSA_BUCLE = 100;

    public const int VIDAS_INICIALES = 3;
    public const int PUNTOS_ENEMIGO = 50;
    public const int MAX_DISPAROS = 8;
    public const int MAX_ENEMIGOS = 50;
    public const int MAX_ASTEROIDES = 50;

    public static Random r = new Random();
}
