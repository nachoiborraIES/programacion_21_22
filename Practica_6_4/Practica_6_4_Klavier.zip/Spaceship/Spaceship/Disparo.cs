﻿using System;

/*
 * Disparos de la nave. Subtipo de sprite.
 */
class Disparo : Sprite
{
    private bool activo;

    public Disparo()
    {
        activo = false;
        imagen = "-";
    }

    public void SetActivo(bool a)
    {
        activo = a;
    }

    public bool GetActivo()
    {
        return activo;
    }

    public override void Dibujar()
    {
        if (activo)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            base.Dibujar();
            Console.ResetColor();
        }
    }
}
