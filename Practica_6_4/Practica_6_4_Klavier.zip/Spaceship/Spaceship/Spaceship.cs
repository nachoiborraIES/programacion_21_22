﻿using System;

/*
 * Programa principal de Spaceship
 * Se centra en la lógica de alternar entre pantalla de partida y de bienvenida
 */
class Spaceship
{
    static void Main()
    {
        Bienvenida b;
        Console.CursorVisible = false;
        Console.WindowWidth = Configuracion.ANCHO_PANTALLA;
        Console.WindowHeight = Configuracion.ALTO_PANTALLA;
        do
        {
            b = new Bienvenida();
            b.Lanzar();
            if (!b.GetSalir())
            {
                Console.Clear();
                Partida p = new Partida();
                p.Lanzar();
                Console.Clear();
            }
        }
        while (!b.GetSalir());

        Console.Clear();
    }
}