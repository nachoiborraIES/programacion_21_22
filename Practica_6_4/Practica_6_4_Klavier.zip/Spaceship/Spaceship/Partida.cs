﻿using System;

/*
 * Clase para gestionar la partida principal
 */
class Partida
{
    public void Lanzar()
    {
        ConsoleKeyInfo tecla = new ConsoleKeyInfo();

        Nave nave = new Nave();
        Enemigo[] enemigos = new Enemigo[Configuracion.MAX_ENEMIGOS];
        Asteroide[] asteroides = new Asteroide[Configuracion.MAX_ASTEROIDES];
        for (int i = 0; i < enemigos.Length; i++)
        {
            enemigos[i] = new Enemigo();
        }
        for (int i = 0; i < asteroides.Length; i++)
        {
            asteroides[i] = new Asteroide();
        }

        do
        {
            nave.Dibujar();
            for (int i = 0; i < enemigos.Length; i++)
            {
                if (enemigos[i].GetActivo())
                    enemigos[i].Dibujar();
                else
                    enemigos[i].IntentarActivar(nave);
            }
            for (int i = 0; i < asteroides.Length; i++)
            {
                if (asteroides[i].GetActivo())
                    asteroides[i].Dibujar();
                else
                    asteroides[i].IntentarActivar(nave);
            }

            Thread.Sleep(Configuracion.PAUSA_BUCLE);
            if (Console.KeyAvailable)
            {
                while (Console.KeyAvailable)
                    tecla = Console.ReadKey(true);

                if (tecla.Key == ConsoleKey.UpArrow)
                    nave.MoverA(nave.GetX(), nave.GetY() - 1);

                else if (tecla.Key == ConsoleKey.DownArrow)
                    nave.MoverA(nave.GetX(), nave.GetY() + 1);

                else if (tecla.Key == ConsoleKey.Spacebar)
                    nave.Disparar();
            }

            nave.MoverDisparo();
            for (int i = 0; i < enemigos.Length; i++)
            {
                if (enemigos[i].GetActivo())
                    enemigos[i].Mover();
                enemigos[i].ComprobarColisionConNave(nave);
            }
            for (int i = 0; i < asteroides.Length; i++)
            {
                if (asteroides[i].GetActivo())
                    asteroides[i].Mover();
                asteroides[i].ComprobarColisionConNave(nave);
            }
                nave.ComprobarColisionConEnemigo(enemigos, asteroides);
            ActualizarHUD(nave);
        }
        while (tecla.Key != ConsoleKey.Escape && nave.GetVidas() > 0);
        Console.Clear();
    }

    public void ActualizarHUD(Nave nave)
    {
        Console.SetCursorPosition(Configuracion.ANCHO_PANTALLA - 15, 0);
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write("Puntos: {0}", nave.GetPuntos());

        Console.SetCursorPosition(Configuracion.ANCHO_PANTALLA - 15,
            Configuracion.ALTO_PANTALLA - 1);
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("Vidas: {0}", nave.GetVidas());

        Console.ResetColor();
    }
}