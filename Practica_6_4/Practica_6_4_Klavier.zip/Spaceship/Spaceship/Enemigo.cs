﻿/* Enemigos del juego. Subtipo de Sprite */
class Enemigo : Sprite
{
    private bool activo;

    public Enemigo()
    {
        activo = false;
        x = Configuracion.ANCHO_PANTALLA - 1;
        y = Configuracion.r.Next(1, Configuracion.ALTO_PANTALLA - 1);
        imagen = "X";
    }

    public bool GetActivo()
    {
        return activo;
    }
    public void SetActivo(bool a)
    {
        activo = a;
    }

    public void IntentarActivar(Nave nave)
    {
        int r;
        if (nave.GetPuntos() < 500)
        {
            r = Configuracion.r.Next(0, 151);
            if (r < 1)
                activo = true;
        }
        else if (nave.GetPuntos() > 500 && nave.GetPuntos() < 1000)
        {
            r = Configuracion.r.Next(0, 151);
            if (r < 2)
                activo = true;
        }
        else
        {
            r = Configuracion.r.Next(0, 151);
            if (r < 4)
                activo = true;
        }
    }
    public void Mover()
    {
        if (x > 1)
            MoverA(x - 1, y);
        else
        {
            activo = false;
            MoverA(Configuracion.ANCHO_PANTALLA - 1, y);
        }
    }
    public override void MoverA(int cx, int cy)
    {
        base.MoverA(cx - 1, cy);
    }
    public void ComprobarColisionConNave(Nave nave)
    {
        
        if(activo && ColisionaCon(nave))
        {
            activo = false;
            MoverA(Configuracion.ANCHO_PANTALLA - 1, y);
            nave.SetVidas(nave.GetVidas() - 1);
        }
    }
    public override void Dibujar()
    {
        if (activo)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            base.Dibujar();
            Console.ResetColor();
        }
    }
}