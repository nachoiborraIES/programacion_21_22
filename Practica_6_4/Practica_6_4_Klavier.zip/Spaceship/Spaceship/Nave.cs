﻿using System;

/*
 * La nave. Subtipo de Sprite.
 */
class Nave : Sprite
{
    private Disparo[] disparos;
    private int vidas;
    private int puntos;
    public Nave()
        : this(4, Configuracion.ALTO_PANTALLA / 2)
    {
    }
    public Nave(int cx, int cy)
    {
        vidas = Configuracion.VIDAS_INICIALES;
        disparos = new Disparo[Configuracion.MAX_DISPAROS];
        for (int i = 0; i < disparos.Length; i++)
            disparos[i] = new Disparo();
        imagen = ">";
        x = cx;
        y = cy;
    }
    public Disparo[] GetDisparos()
    {
        return disparos;
    }
    public int GetVidas()
    {
        return vidas;
    }
    public int GetPuntos()
    {
        return puntos;
    }
    public void SetVidas(int vidas)
    {
        this.vidas = vidas;
    }
    public void SetPuntos(int puntos)
    {
        this.puntos = puntos;
    }

    public void Disparar()
    {
        bool encontrado = false;
        int i = 0;
        while (i < disparos.Length && !encontrado)
        {
            if (!disparos[i].GetActivo())
            {
                disparos[i].MoverA(x + 1, y);
                disparos[i].SetActivo(true);
                encontrado = true;
            }
            i++;
        }

    }
    public void MoverDisparo()
    {
        foreach (Disparo d in disparos)
        {
            if (d.GetActivo())
            {
                if (d.GetX() < Configuracion.ANCHO_PANTALLA - 1)
                    d.MoverA(d.GetX() + 1, d.GetY());
                else
                {
                    d.SetActivo(false);
                    d.MoverA(x, y);
                }
            }
        }
    }
    public override void MoverA(int cx, int cy)
    {
        if (cx >= 0 && cx <= Configuracion.ANCHO_PANTALLA && cy >= 1 &&
            cy <= Configuracion.ALTO_PANTALLA - 2)
        {
            Console.SetCursorPosition(x, y);
            for (int i = 0; i < imagen.Length; i++)
                Console.Write(" ");
            SetX(cx);
            SetY(cy);
        }
    }
    public void ComprobarColisionConEnemigo(Enemigo[] enemigos,
        Asteroide[] asteroides)
    {
        foreach (Disparo d in disparos)
        {
            if (d.GetActivo())
            {
                foreach (Enemigo e in enemigos)
                {
                    if (e.GetActivo() && e.ColisionaCon(d))
                    {
                        e.SetActivo(false);
                        e.MoverA(Configuracion.ANCHO_PANTALLA - 1, y);
                        d.SetActivo(false);
                        d.MoverA(x, y);
                        SetPuntos(puntos + Configuracion.PUNTOS_ENEMIGO);
                    }
                }
                foreach(Asteroide a in asteroides)
                {
                    if (a.GetActivo() && a.ColisionaCon(d))
                    {
                        d.SetActivo(false);
                        d.MoverA(x, y);
                    }
                }
            }
        }
    }
    public override void Dibujar()
    {
        Console.ForegroundColor = ConsoleColor.DarkMagenta;
        base.Dibujar();
        foreach (Disparo d in disparos)
            d.Dibujar();
        Console.ResetColor();
    }
}
