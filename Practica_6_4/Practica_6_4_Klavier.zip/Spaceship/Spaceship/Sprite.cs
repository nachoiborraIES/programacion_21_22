﻿using System;
/* 
 * Clase para representar todos los sprites del juego
 */
class Sprite
{
    protected int x;
    protected int y;
    protected string imagen;

    public int GetX()
    {
        return x;
    }
    public int GetY()
    {
        return y;
    }
    public string GetImagen()
    {
        return imagen;
    }
    public void SetX(int cx)
    {
        x = cx;
    }
    public void SetY(int cy)
    {
        y = cy;
    }
    public void SetImagen(string img)
    {
        imagen = img;
    }

    public virtual void MoverA(int cx, int cy)
    {
        if (cx >= 0 && cx <= Configuracion.ANCHO_PANTALLA - imagen.Length)
        {
            Console.SetCursorPosition(x, y);
            for (int i = 0; i < imagen.Length; i++)
                Console.Write(" ");
            SetX(cx);
            SetY(cy);
        }
    }
    public bool ColisionaCon(Sprite s)
    {
        bool colisionY = GetY() == s.GetY();
        bool colisionX = GetX() == s.GetX() || GetX() == s.GetX() - 1 ||
                         GetX() - 1 == s.GetX();
        return colisionX && colisionY;
    }
    public virtual void Dibujar()
    {
        Console.SetCursorPosition(x, y);
        Console.Write(imagen);
    }
}

