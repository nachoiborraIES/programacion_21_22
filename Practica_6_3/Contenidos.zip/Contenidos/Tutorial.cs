﻿//Clase Tutorial hija de Contenido.
using System;
class Tutorial : Contenido
{
    protected int sesiones;
    public int Sesiones
    {
        get { return sesiones; }
        set { sesiones = value; }
    }
    public Tutorial(string titulo, int sesiones)
    : base(titulo)
    {
        this.sesiones = sesiones;
    }
    public override string ToString()
    {
        return base.ToString() + ", "+sesiones;
    }

}
