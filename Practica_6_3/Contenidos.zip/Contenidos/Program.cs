﻿// Ejercicio Contenidos
// Programa Principal

//Función RellenarArray - Pide al usuario rellenar el array manualmente.
static void RellenarArray(Contenido[] contenidos)
{

    Console.Clear();
    int tipoContenido, paginas, minutos, sesiones;
    bool color;
    string titulo,tematica;

    for (int i = 0; i < contenidos.Length; i++)
    {
        Console.WriteLine("Introduzca el tipo de contenido");
        Console.WriteLine("1. Libro  / 2. Tutorial /3. Documental ");
        tipoContenido = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Titulo: ");
        titulo = Console.ReadLine();
        if (tipoContenido == 1)
        {
            Console.Write("Introduce el numero de paginas: ");
            paginas = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Introduce si el contenido es a color o en blanco y negro: ");
            Console.WriteLine("1. Blanco y negro / 2. Color");
            color = Convert.ToInt32(Console.ReadLine()) == 2;
            contenidos[i] = new Libro(titulo,paginas,color);
        }
        else if (tipoContenido == 2)
        {
            Console.Write("Introduce el numero de sesiones: ");
            sesiones = Convert.ToInt32(Console.ReadLine());
            contenidos[i] = new Tutorial(titulo,sesiones);
        }
        else if (tipoContenido == 3)
        {
            Console.Write("Introduce la duracion en minutos: ");
            minutos = Convert.ToInt32(Console.ReadLine());
            Console.Write("Introduce la tematica del documental: ");
            tematica = Console.ReadLine();
            contenidos[i] = new Documental(titulo,minutos,tematica);
        }
    }
}
//Función Listado - Muestra en vista lista el contenido del array.
static void Listado(Contenido[] contenidos)
{
    Console.Clear();
    Console.WriteLine("::::::::::::::::");
    Console.WriteLine("LISTADO ORDENADO");
    Console.WriteLine("::::::::::::::::");

    for (int i = 0; i < contenidos.Length; i++)
    {
        if (contenidos[i] is Libro)
            Console.ForegroundColor = ConsoleColor.Yellow;
        else if (contenidos[i] is Documental)
            Console.ForegroundColor = ConsoleColor.Green;
        else if (contenidos[i] is Tutorial)
            Console.ForegroundColor = ConsoleColor.Blue;

        Console.WriteLine(contenidos[i]);
        Console.ResetColor();
    }
    
}
//Función ListadoDescargable - Muestra en lista SOLO descargables y el peso de estos.
static void ListadoDescargable(Contenido[] contenidos)
{
    Console.WriteLine();
    Console.WriteLine(":::::::::::::::::::");
    Console.WriteLine("LISTADO DESCARGABLE");
    Console.WriteLine(":::::::::::::::::::");
    foreach (Contenido c in contenidos)
    {
        if (c is IDescargable)
        {
            if (c is Libro)
                Console.ForegroundColor = ConsoleColor.Yellow;
            else if (c is Documental)
                Console.ForegroundColor = ConsoleColor.Green;

            Console.WriteLine(c.ToString()+((IDescargable)c).calcularTamano()+" Mb");
            Console.ResetColor();
            Console.WriteLine();
        }
    }
}

Contenido[] contenidos = new Contenido[10];
RellenarArray(contenidos);
Array.Sort(contenidos);
Listado(contenidos);
ListadoDescargable(contenidos);

    
