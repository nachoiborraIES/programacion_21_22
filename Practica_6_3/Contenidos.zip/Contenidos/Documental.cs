﻿//Clase Documental hija de Contenido y participé de IDescargable.
using System;
class Documental : Contenido, IDescargable
{
    protected int minutos;
    protected string tematica;
    public string Tematica
    {
        get { return tematica; }
        set { tematica = value; }
    }
    public int Minutos
    {
        get { return minutos; }
        set { minutos = value; }
    }
    public Documental(string titulo, int minutos, string tematica)
    : base(titulo)
    {
        this.minutos = minutos;
        this.tematica = tematica;
    }
    double IDescargable.calcularTamano()
    {
        double tamano;
        tamano = minutos * 15;
        return tamano;
    }
    public override string ToString()
    {
        return base.ToString() + ", "+tematica+", "+minutos;
    }
}
