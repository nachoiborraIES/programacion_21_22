﻿//Interfaz IDescargable con metodo sin parametros.
interface IDescargable
{
    double calcularTamano();
}