﻿//Clase abstracta Contenido.
using System;
abstract class Contenido :IComparable <Contenido>
{
    protected string titulo;

    public Contenido(string titulo)
    {
        this.titulo = titulo;
    }
    public override string ToString()
    {
        return titulo;
    }
    public int CompareTo(Contenido otroTitulo)
    {
        return this.titulo.CompareTo(otroTitulo.titulo);
    }
}
