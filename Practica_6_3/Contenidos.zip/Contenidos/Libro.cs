﻿//Clase Libro hija de Contenido y participé de IDescargable.
using System;
class Libro : Contenido,IDescargable
{
    protected int paginas;
    protected bool color;
    public int Paginas
    {
        get { return paginas; }
        set { paginas = value; }
    }
    public bool Color
    {
        get { return color; }
        set { color = value; }
    }
    public Libro(string titulo, int paginas, bool color)
    : base(titulo)
    {
        this.paginas = paginas;
        this.color = color;
    }
    double IDescargable.calcularTamano()
    {
        double tamano;
        if(color)
        {
            tamano=paginas* 0.03;
        }
        else
        {
            tamano = paginas * 0.01;
        }
        return tamano;
    }
    public override string ToString()
    {
        return base.ToString() + ", "+paginas;
    }
}
