﻿/*
 * Clase para representar cada hotel
 */

using System;

class Hotel
{
    string nombre;
    string localidad;
    float precioNoche;
    int estrellas;

    public Hotel(string nombre, string localidad, float precioNoche,
        int estrellas)
    {
        this.nombre = nombre;
        this.localidad = localidad;
        if (precioNoche > 0)
            this.precioNoche = precioNoche;
        if (estrellas > 0 && estrellas < 5)
            this.estrellas = estrellas;
    }

    public void Mostrar()
    {
        string asteriscos = new String('*', estrellas);
        Console.WriteLine("Hotel {0}, {1} ({2} eur/noche, {3}", nombre,
            localidad, precioNoche, asteriscos + ")");
    }

    public string Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }

    public string Localidad
    {
        get { return localidad; }
        set { localidad = value; }
    }

    public float PrecioNoche
    {
        get { return precioNoche; }
        set { precioNoche = value; }
    }

    public int Estrellas
    {
        get { return estrellas; }
        set {
            if (value > 0 && value < 5)
                estrellas = value;
        }
    }
}
