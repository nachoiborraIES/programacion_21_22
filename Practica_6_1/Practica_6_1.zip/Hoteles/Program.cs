﻿/*
 * Programa que muestra un menú de opciones para añadir hoteles a un array de
 * hoteles, ordenarlos por precio de manera ascendente y buscarlos según cuántas
 * estrellas tengan.
 * 
 * Klavier Navarro
 */

using System;

internal class Program
{
    enum opciones { NUEVO = 1, BARATOS, ESTRELLAS, SALIR };
    static void Main()
    {
        int opcion, nHoteles = 0;

        Hotel[] hoteles = new Hotel[20];
        do
        {
            Console.WriteLine("Elige una opción del menú:");
            Console.WriteLine("{0}. Nuevo hotel", (int)opciones.NUEVO);
            Console.WriteLine("{0}. Hoteles baratos", (int)opciones.BARATOS);
            Console.WriteLine("{0}. Hoteles por estrellas",
                (int)opciones.ESTRELLAS);
            Console.WriteLine("{0}. Salir", (int)opciones.SALIR);

            opcion = Convert.ToInt32(Console.ReadLine());

            switch (opcion)
            {
                default:
                    Console.WriteLine("Opción incorrecta");
                    break;

                case 1:
                    nuevoHotel(hoteles, ref nHoteles);
                    break;

                case 2:
                    ordenarHoteles(hoteles, nHoteles);
                    break;

                case 3:
                    buscarHoteles(hoteles, nHoteles);
                    break;

                case 4:
                    Console.WriteLine("Fin del programa");
                    break;
            }
        }
        while (opcion != (int)opciones.SALIR);
    }

    static void nuevoHotel(Hotel[] hoteles, ref int nHoteles)
    {
        bool parsea = false;
        float precio;
        int estrellas;

        if (nHoteles < hoteles.Length)
        {
            hoteles[nHoteles] = new Hotel("", "", 1, 1);

	        Console.Write("Nombre del hotel: ");
	        hoteles[nHoteles].Nombre += Console.ReadLine();

	        Console.Write("Localidad del hotel: ");
	        hoteles[nHoteles].Localidad += Console.ReadLine();

	        do
	        {
		        Console.Write("Precio por noche: ");
		        if (Single.TryParse(Console.ReadLine(), out precio))
                {
                    parsea = true;
                    hoteles[nHoteles].PrecioNoche += precio - 1;
                }
			        
	        }
	        while (!parsea || precio < 0) ;

            parsea = false;

            do
            {
                Console.Write("Estrellas: ");
                if (Int32.TryParse(Console.ReadLine(), out estrellas))
                {
                    parsea = true;
                    hoteles[nHoteles].Estrellas += estrellas - 1;
                }
            }
            while (!parsea || estrellas < 0 || estrellas > 5);
            nHoteles++;
        }
        else
	        Console.WriteLine("No caben más hoteles");
    }

    static void ordenarHoteles(Hotel[] hoteles, int nHoteles)
    {
        if (nHoteles > 0)
        {
            for (int i = 0; i < nHoteles; i++)
            {
                for (int j = 0; j < nHoteles - i - 1; j++)
                {
                    if (hoteles[j].PrecioNoche >= hoteles[j + 1].PrecioNoche)
                    {
                        Hotel hotelAux = hoteles[j];
                        hoteles[j] = hoteles[j + 1];
                        hoteles[j + 1] = hotelAux;
                    }
                }
            }
            for (int i = 0; i < nHoteles; i++)
            {
                hoteles[i].Mostrar();
            }
        }
        else
            Console.WriteLine("Todavía no hay hoteles");
    }

    static void buscarHoteles(Hotel[] hoteles, int nHoteles)
    {
        int estrellas;

        Console.Write("Escribe la cantidad de estrellas: ");
        if (Int32.TryParse(Console.ReadLine(), out estrellas))
        {
            for (int i = 0; i < nHoteles; i++)
            {
                if (hoteles[i].Estrellas >= estrellas)
                {
                        hoteles[i].Mostrar();
                }
            }
        }
        else
            Console.WriteLine("Número de estrellas incorrecto");
    }
}
